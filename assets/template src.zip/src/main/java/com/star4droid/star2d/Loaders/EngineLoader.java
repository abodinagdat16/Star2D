package com.star4droid.star2d.Loaders;

public interface EngineLoader {
	public void onLoad(Object... params);
}