package com.star4droid.star2d.player;
import android.view.MotionEvent;

public class ItemScript {
	private PlayerItem playerItem;
	public ItemScript(PlayerItem item){
		playerItem = item;
	}
	
	public void setItem(PlayerItem item){
		playerItem=item;
	}
	
	public void onClick(){
		
	}
	public void onTouchStart(MotionEvent event){
		
	}
	public void onTouchEnd(MotionEvent event){
		
	}
	public void onBodyCreated(){
		
	}
	public void onBodyUpdate(){
		
	}
	public void onCollisionBegin(PlayerItem other){
		
	}
	public void onCollisionEnd(PlayerItem other){
		
	}
	
	public final PlayerItem getPlayerItem(){
		return playerItem;
	}
}