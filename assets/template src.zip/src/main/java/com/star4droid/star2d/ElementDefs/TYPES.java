package com.star4droid.star2d.ElementDefs;

public class TYPES {
	public static final String DYNAMIC="DYNAMIC",KINAMATIC="KINAMATIC",STATIC="STATIC";
}