package com.star4droid.star2d;
import android.os.Bundle;

public class PortraitPlayer extends LandscapePlayer {
	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
	}
	
}