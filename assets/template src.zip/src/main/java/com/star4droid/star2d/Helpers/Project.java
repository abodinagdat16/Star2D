package com.star4droid.star2d.Helpers;

import android.net.Uri;
import java.util.ArrayList;

/*
ToDo : all scene related files (events/bodies/config..etc) in one folder....
- not important :| 
*/

public class Project {
	private String path;
	public Project(String p){
		path = p;
	}
	public String getPath(){
		return path;
	}
	
	public String get(String name){
		return path+"/"+name+"/";
	}
	
	public String getConfig(String scene){
		return path+"/configs/"+scene+".json";
	}
	
	public String getJoints(String scene){
		return path+"/joints/"+scene+"/";
	}
	
	public String getDex(String scene){
		return path+"/dex/scenes.dex";//+scene+".dex";
	}
	
	public String getName(){
		return Uri.parse(path).getLastPathSegment();
	}
	
	public String getScenesPath(){
		return path+"/scenes/";
	}
	
	public String getImagesPath(){
		return path+"/images/";
	}
}