package com.star4droid.Game;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.star4droid.star2d.PortraitPlayer;
import com.star4droid.star2d.LandscapePlayer;
import com.star4droid.star2d.Helpers.Project;
import com.star4droid.star2d.Helpers.FileUtil;
import com.star4droid.star2d.Utils;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
	TextView text;
	SharedPreferences sh;
	long startTime;
	Intent intent;
	String extractPath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Utils.hideSystemUi(getWindow());
		text = findViewById(R.id.text);
		extractPath = getFilesDir()+"";
		startTime = System.currentTimeMillis();
		sh = getSharedPreferences("sh",Activity.MODE_PRIVATE);
		try {
			if(sh.getInt("version",0)==Utils.getInt(Utils.readAssetFile("version",this))){
				startGame();
			} else {
				FileUtil.deleteFile(extractPath+"/game/");
				new Thread(){
					@Override
					public void run(){
						Looper.prepare();
						try {
						Utils.extractAssetFile(MainActivity.this,"project.zip",extractPath+"/project.zip");
						//Utils.unzipf(extractPath+"/project.zip",extractPath+"/game/","tulsgskdiensl626__Xxmoishs");
						//FileUtil.copyDir(extractPath+"/game/",getFilesDir()+"/game/");
						//Utils.unzipf(getAssets().open("project.zip"),getFilesDir()+"/game/","tulsgskdiensl626__Xxmoishs");
						Utils.extractByHeaders(extractPath+"/project.zip",getFilesDir()+"/game/","tulsgskdiensl626__Xxmoishs");
						sh.edit().putInt("version",Utils.getInt(Utils.readAssetFile("version",MainActivity.this)));
						FileUtil.deleteFile(extractPath+"/project.zip");
						startGame();
						} catch(final Exception ex){
							new Handler(Looper.getMainLooper()).post(()->{
								Utils.showMessage(MainActivity.this,Log.getStackTraceString(ex));
							});
						}
					}
				}.start();
			}
		} catch(Exception ex){
			Utils.showMessage(this,"Error : \n"+Log.getStackTraceString(ex));
		}
    }
	
	public void startGame(){
		//prepare the project...
		ArrayList<String> arrayList = new ArrayList<>();
		FileUtil.listDir(getFilesDir()+"/game/",arrayList);
		if(arrayList.size()==0){
			new Handler(Looper.getMainLooper()).post(()->{
				Utils.showMessage(this,"Game Not Found!!");
			});
			return;
		}
		Project project = new Project(arrayList.get(0));
		intent = new Intent(Intent.ACTION_VIEW);
		String cfg=FileUtil.readFile(project.getConfig("scene1"));
		intent.putExtra("scene","scene1");
		intent.putExtra("path",project.getPath());
		String or=(cfg.equals("")?"":Utils.getProperty(cfg).getString("or"));
		if(or.equals("")) intent.setClass(this,PortraitPlayer.class);
		else intent.setClass(this,LandscapePlayer.class);
		
		if(System.currentTimeMillis()-startTime>=3000){
		startActivity(intent);
		finish();
		} else {
			new Timer().schedule(new TimerTask(){
				@Override
				public void run() {
					startActivity(intent);
					finish();
				}
			},3000);
		}
	}
}